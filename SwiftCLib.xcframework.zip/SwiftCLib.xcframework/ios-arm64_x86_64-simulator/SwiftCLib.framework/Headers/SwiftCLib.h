//
//  SwiftCLib.h
//  SwiftCLib
//
//  Created by Kirow on 16.07.2022.
//

#import <Foundation/Foundation.h>

//! Project version number for SwiftCLib.
FOUNDATION_EXPORT double SwiftCLibVersionNumber;

//! Project version string for SwiftCLib.
FOUNDATION_EXPORT const unsigned char SwiftCLibVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SwiftCLib/PublicHeader.h>


