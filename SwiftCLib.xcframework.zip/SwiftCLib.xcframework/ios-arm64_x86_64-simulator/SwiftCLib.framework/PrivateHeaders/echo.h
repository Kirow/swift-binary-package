//
//  echo.h
//  SwiftCLib
//
//  Created by Kirow on 16.07.2022.
//

#ifndef echo_h
#define echo_h

#include <stdio.h>
void callCfunction(const char* name, int x, int y);

#endif /* echo_h */
